var Aluno1 = {
  ra: '0030481811515',
  nome: 'Maria da Silveira'
}
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);

Aluno1.ra = '0030481911919';
Aluno1.nome = 'Laura Lopes';
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);

Aluno1['ra'] = '0030481911010';
Aluno1['nome'] = 'Marcos Vinícius de Souza';
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);